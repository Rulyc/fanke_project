window.onscroll=function(){
			var scrollTop=document.documentElement.scrollTop || document.body.scrollTop;
			var backTop=document.querySelector(".fixed>ul>li.blackTop>a");
			backTop.onclick=function(){
				scrollTop=0;
			}
		}