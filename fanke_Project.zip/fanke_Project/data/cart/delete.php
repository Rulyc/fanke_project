<?php
//data/cart/delete.php
require("../init.php");
@$item_id=$_REQUEST["item_id"];
$sql="delete from fk_cart_item where item_id=$item_id";
$result=mysqli_query($conn,$sql);
$sql="select * from fk_cart_item where item_id=$item_id ";
$result=mysqli_query($conn,$sql);
$row=mysqli_fetch_all($result,1);
echo json_encode($row);
