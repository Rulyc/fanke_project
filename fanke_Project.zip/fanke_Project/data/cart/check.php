<?php
//data/cart/check.php
require_once("../init.php");
@$item_id=$_REQUEST["item_id"];
@$check=$_REQUEST["check"];
$sql="update fk_cart_item set is_checked=$check where item_id=$item_id";
$result=mysqli_query($conn,$sql);
$sql="select * from fk_cart_item where item_id=$item_id ";
$result=mysqli_query($conn,$sql);
$row=mysqli_fetch_all($result,1);
echo json_encode($row);