<?php
//data/cart/add.php
require("../init.php");
session_start();
@$uid=$_SESSION["uid"];
@$spec_id=$_REQUEST["spec_id"];
@$count=$_REQUEST["count"];
@$spec_size=$_REQUEST["spec_size"];
if($spec_id!=null && $count!=null && $spec_size!=null){
    $sql="select item_id,count from fk_cart_item where item_user_id=$uid and          item_spec_id=$spec_id and item_size=$spec_size";
    if(mysqli_error($conn)){
        echo mysqli_error($conn);
    }
	$result=mysqli_query($conn,$sql);
	$row=mysqli_fetch_row($result);
	//var_dump($row);
	if($row[0]==null){
		$sql="insert into fk_cart_item values (null,$spec_id,$uid,$count,1,$spec_size)";
		mysqli_query($conn,$sql);
	}else{
		if($count>0){
       		$sql="update fk_cart_item set count=$row[1]+$count where item_id=$row[0]";
       		mysqli_query($conn,$sql);
        }
	}
	echo json_encode(["ok"=>1,"msg"=>"ok!"]);
}else{
    echo json_encode(["ok"=>0,"msg"=>""]);
}