<?php
//data/cart/get.php
header("Content-Type:application/json");
require_once("../init.php");
session_start();
@$uid=$_SESSION["uid"];
if($uid!=null){
	$sql="SELECT *, (select pic_sImg from fk_pic where fk_spec_id=spec_id limit 1) as pic FROM `fk_cart_item` INNER join fk_spec on spec_id=item_spec_id where item_user_id=$uid";
	$result=mysqli_query($conn,$sql);
	echo json_encode(mysqli_fetch_all($result,1));
}
?>