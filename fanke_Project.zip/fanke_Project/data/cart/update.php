<?php
require("../init.php");
@$item_id=$_REQUEST["item_id"];
@$count=$_REQUEST["count"];
if($count>0){
	$sql="update fk_cart_item set count=$count where item_id=$item_id";
	$result=mysqli_query($conn,$sql);
}else{
      $sql="delete from fk_cart_item where item_id=$item_id";
      $result=mysqli_query($conn,$sql);
}
    $sql="select * from fk_cart_item where item_id=$item_id ";
    $result=mysqli_query($conn,$sql);
    $row=mysqli_fetch_all($result,1);
	echo json_encode($row);

?>
