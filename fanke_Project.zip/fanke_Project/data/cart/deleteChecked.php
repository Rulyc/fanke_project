﻿<?php
	require_once("../init.php");
	session_start();
	@$uid=$_SESSION["uid"];
	$sql="delete from fk_cart_item where item_user_id=$uid and is_checked=1;";
    $result=mysqli_query($conn,$sql);
    $sql="select * from fk_cart_item where item_user_id=$uid ";
    $result=mysqli_query($conn,$sql);
    $row=mysqli_fetch_all($result,1);
    echo json_encode($row);
?>