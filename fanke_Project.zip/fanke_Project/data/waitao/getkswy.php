<?php
 require("../init.php");
  //查找数据
  $sql="SELECT kswy_id,kswy_img,kswy_bargin,kswy_href,kswy_title,kswy_price FROM fk_kswy";
  $result=mysqli_query($conn,$sql);
  if(mysqli_error($conn)){
       echo mysqli_error($conn);
  }
  $rows=mysqli_fetch_all($result,MYSQLI_ASSOC);
   echo  json_encode($rows);

?>