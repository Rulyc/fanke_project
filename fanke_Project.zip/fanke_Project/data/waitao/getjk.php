<?php
 require("../init.php");
  //查找数据
  $sql="SELECT jk_id,jk_img,jk_bargin,jk_href,jk_title,jk_price FROM fk_jiake";
  $result=mysqli_query($conn,$sql);
  if(mysqli_error($conn)){
       echo mysqli_error($conn);
  }
  $rows=mysqli_fetch_all($result,MYSQLI_ASSOC);
   echo  json_encode($rows);

?>