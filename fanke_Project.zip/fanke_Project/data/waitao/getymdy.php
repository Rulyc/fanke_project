<?php
 require("../init.php");
  //查找数据
  $sql="SELECT ymdy_id,ymdy_img,ymdy_bargin,ymdy_href,ymdy_title,ymdy_price FROM fk_ymdy";
  $result=mysqli_query($conn,$sql);
  if(mysqli_error($conn)){
       echo mysqli_error($conn);
  }
  $rows=mysqli_fetch_all($result,MYSQLI_ASSOC);
   echo  json_encode($rows);

?>