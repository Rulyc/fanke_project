<?php
 require("../init.php");
  //查找数据
  $sql="SELECT cq_id,cq_img,cq_bargin,cq_href,cq_title,cq_price FROM fk_chaoqing";
  $result=mysqli_query($conn,$sql);
  if(mysqli_error($conn)){
       echo mysqli_error($conn);
  }
  $rows=mysqli_fetch_all($result,MYSQLI_ASSOC);
   echo  json_encode($rows);

?>