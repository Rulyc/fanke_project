<?php
//data/products/getProductById.php
header("Content-Type:application/json");
require_once("../init.php");
$output=[
	//"product"=>{...},
	//"pics"=>[...]
];
@$pic_id=$_REQUEST["pic_id"];
if($pic_id!=null){
	$sql="SELECT * FROM `fk_spec` where spec_id=$pic_id";
	$result=mysqli_query($conn,$sql);
	$product=mysqli_fetch_all($result,1)[0];
	$output["product"]=$product;

	$sql="SELECT * FROM `fk_pic` where fk_spec_id=$pic_id";
	$result=mysqli_query($conn,$sql);
	$output["pics"]=mysqli_fetch_all($result,1);

	echo json_encode($output);
}