<?php
require("../init.php");
$output = [];
@$pno = $_REQUEST["pno"];            //pno 页码0-9
@$pageSize = $_REQUEST["pageSize"];  //pageSize 页大小
$sql = "SELECT count(speak_id) FROM fk_speak";
$result = mysqli_query($conn,$sql); //发送sql 语句
$row = mysqli_fetch_row($result);   //抓取一行记录
$pageCount = ceil($row[0]/$pageSize);

$start = ($pno-1)*$pageSize;
$sql =  " SELECT * FROM fk_speak LIMIT $start,$pageSize";
$result = mysqli_query($conn,$sql);
if(mysqli_error($conn)){
  echo mysqli_error($conn);
}
$rows = mysqli_fetch_all($result,MYSQLI_ASSOC);
$output = [
          "pno"=>$pno,               //当前页码
          "pageSize"=>$pageSize,     //页大小
          "pageCount"=>$pageCount,   //总页数
          "data"=>$rows              //当前页内容
          ];
echo json_encode($output);