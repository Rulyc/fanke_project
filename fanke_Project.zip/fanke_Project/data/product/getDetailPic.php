<?php
 require("../init.php");
  //查找数据
  $sql="SELECT yr_img FROM fk_yr_details";
  $result=mysqli_query($conn,$sql);
  if(mysqli_error($conn)){
       echo mysqli_error($conn);
  }
  $rows=mysqli_fetch_all($result,MYSQLI_ASSOC);
   echo  json_encode($rows);

?>