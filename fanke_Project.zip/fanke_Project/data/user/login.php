﻿<?php
    header("Content-Type:application/json");
    //1.加载初始化文件
    require("../init.php");
    //2.获取用户姓名及登录密码
    @$uname=$_REQUEST["uname"];
    @$upwd=$_REQUEST["upwd"];
    //3.创建sql读取用户姓名及登录密码
    $sql="SELECT * from fk_user where uname='$uname' AND upwd=md5('$upwd') ";
    //4.判断sql语法是否正确
    $result=mysqli_query($conn,$sql);
    if(mysqli_error($conn)){
         echo mysqli_error($conn);
    }
    //5.抓取查询结果
     $row=mysqli_fetch_row($result);
    //6.将查询结果转为json格式发送
     //echo  json_encode($rows);
     if($row==null){
       die('{"code":-1,"msg":"用户名或者密码不正确"}');
     }else{
            $uid=$row[0];
           // var_dump($uid);
     		session_start();//重新将session拿到内存中
     		$_SESSION["uid"]=$uid;
       die('{"code":1,"msg":"登录成功"}');
     }

?>