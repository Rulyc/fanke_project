﻿<?php
	require("../init.php");
	//1、获取用户名及密码
	@$phone=$_REQUEST["phone"];
	@$upwd=$_REQUEST["upwd"];
	@$a=$_REQUEST["a"];
    //3、sql语句查询
    $sql ="SELECT * FROM fk_user WHERE uname=$phone";
    $result=mysqli_query($conn,$sql);
    //4、检查sql语句是否有错
    if(mysqli_error($conn)){
      echo mysqli_error($conn);
    }

    //5.输出结果
    $row = mysqli_fetch_row($result);
    if(!$row==null){
        die('{"code":-2,"msg":"当前手机号已经被注册"}');
    }else{
        //判断密码是否为空
        if($upwd==null){
             die('{"code":-1,"msg":"密码不能为空"}');
        }else if($a!="验证通过"){
            die('{"code":-3,"msg":"验证不通过"}');
        }else{
        //当密码不为空时向数据库中插入数据
            $sql="INSERT INTO fk_user (uid,uname,upwd,gender) VALUES(NULL,$phone,md5('$upwd'),'')";
            $result=mysqli_query($conn,$sql);
            if(mysqli_error($conn)){
                  echo mysqli_error($conn);
            }
            //查找插入数据的id
            $row = mysqli_insert_id($conn);
            //var_dump($row);
            //echo $row;
            //echo json_encode($row);
           if(!$row==null){
               die('{"code":1,"msg":"注册成功"}');
            }
        }
    }


?>