<?php
    //1:设置响应数据格式json
    header("Content-Type:application/json");
    //整个项目的初始化(initiailize)页面,其中声明其他多个页面的公共变量
    $conn=mysqli_connect("127.0.0.1","root","","fk",3306);
    $sql="SET NAMES UTF8";
    mysqli_query($conn,$sql);
?>