<?php
//外套上新
    header("Content-Type:application/json");
    //连接数据库
    require("../init.php");
    //查找数据
    $sql="SELECT * FROM fk_waitao";
    $result=mysqli_query($conn,$sql);
    echo json_encode(mysqli_fetch_all($result,1));
?>