<?php
//    获得秒杀商品的数据
    header("Content-Type:application/json");
    require_once("../init.php");
    $sql="SELECT * FROM `fk_miaosha`";
    $result=mysqli_query($conn,$sql);
    echo json_encode(mysqli_fetch_all($result,1));
?>