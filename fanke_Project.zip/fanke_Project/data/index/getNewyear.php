<?php
    require("../init.php");
        //查找数据
        $sql="SELECT * FROM fk_newyear";
        $result=mysqli_query($conn,$sql);
        echo json_encode(mysqli_fetch_all($result,1));
?>